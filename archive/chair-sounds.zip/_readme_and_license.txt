Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - yawfle ( https://freesound.org/people/yawfle/ )

You can find this pack online at: https://freesound.org/people/yawfle/packs/367/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 7052__yawfle__050816_chair_composite.wav
    * url: https://freesound.org/s/7052/
    * license: Attribution
  * 7051__yawfle__050816_chair_15.wav
    * url: https://freesound.org/s/7051/
    * license: Attribution
  * 7050__yawfle__050816_chair_14.wav
    * url: https://freesound.org/s/7050/
    * license: Attribution
  * 7049__yawfle__050816_chair_13.wav
    * url: https://freesound.org/s/7049/
    * license: Attribution
  * 7048__yawfle__050816_chair_12.wav
    * url: https://freesound.org/s/7048/
    * license: Attribution
  * 7046__yawfle__050816_chair_10.wav
    * url: https://freesound.org/s/7046/
    * license: Attribution
  * 7047__yawfle__050816_chair_11.wav
    * url: https://freesound.org/s/7047/
    * license: Attribution
  * 7045__yawfle__050816_chair_09.wav
    * url: https://freesound.org/s/7045/
    * license: Attribution
  * 7044__yawfle__050816_chair_08.wav
    * url: https://freesound.org/s/7044/
    * license: Attribution
  * 7043__yawfle__050816_chair_07.wav
    * url: https://freesound.org/s/7043/
    * license: Attribution
  * 7042__yawfle__050816_chair_06.wav
    * url: https://freesound.org/s/7042/
    * license: Attribution
  * 7041__yawfle__050816_chair_05.wav
    * url: https://freesound.org/s/7041/
    * license: Attribution
  * 7040__yawfle__050816_chair_04.wav
    * url: https://freesound.org/s/7040/
    * license: Attribution
  * 7039__yawfle__050816_chair_03.wav
    * url: https://freesound.org/s/7039/
    * license: Attribution
  * 7038__yawfle__050816_chair_02.wav
    * url: https://freesound.org/s/7038/
    * license: Attribution
  * 7037__yawfle__050816_chair_01.wav
    * url: https://freesound.org/s/7037/
    * license: Attribution


